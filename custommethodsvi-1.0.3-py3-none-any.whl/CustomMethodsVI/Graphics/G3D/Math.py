from __future__ import annotations

import typing

from ...Decorators import Overload, DefaultOverload
from ... import Exceptions
from ... import Math
from ... import Misc


class TransformMatrix3D:
	@classmethod
	def identity(cls) -> TransformMatrix3D:
		return cls(Math.Tensor.Tensor.identity(4, 4))

	@DefaultOverload
	def __init__(self):
		self.__matrix__: Math.Tensor.Tensor = Math.Tensor.Tensor.shaped((
			0, 0, 0, 0,
			0, 0, 0, 0,
			0, 0, 0, 0,
			0, 0, 0, 0
		), 4, 4)

	@Overload
	def __init__(self, forward: Math.Vector.Vector | Vector3D, up: Math.Vector.Vector | Vector3D, translation: Math.Vector.Vector | Vector3D):
		assert forward.dimension == 3, f'Forward vector must be 1x3, got 1x{forward.dimension}'
		assert up.dimension == 3, f'Up vector must be 1x3, got 1x{up.dimension}'
		assert translation.dimension == 3, f'Translation vector must be 1x3, got 1x{translation.dimension}'

		right: Math.Vector.Vector = forward.cross(up)

		m11, m12, m13 = right
		m21, m22, m23 = up
		m31, m32, m33 = forward
		m41, m42, m43 = translation

		self.__matrix__: Math.Tensor.Tensor = Math.Tensor.Tensor.shaped((
			m11, m12, m13, 0,
			m21, m22, m23, 0,
			m31, m32, m33, 0,
			m41, m42, m43, 1
		), 4, 4)

	@Overload
	def __init__(self, m11: float, m12: float, m13: float, m21: float, m22: float, m23: float, m31: float, m32: float, m33: float, m41: float, m42: float, m43: float):
		self.__matrix__: Math.Tensor.Tensor = Math.Tensor.Tensor.shaped((
			m11, m12, m13, 0,
			m21, m22, m23, 0,
			m31, m32, m33, 0,
			m41, m42, m43, 1
		), 4, 4)

	@Overload
	def __init__(self, m11: float, m12: float, m13: float, m14: float, m21: float, m22: float, m23: float, m24: float, m31: float, m32: float, m33: float, m34: float, m41: float, m42: float, m43: float, m44: float):
		self.__matrix__: Math.Tensor.Tensor = Math.Tensor.Tensor.shaped((
			m11, m12, m13, m14,
			m21, m22, m23, m24,
			m31, m32, m33, m34,
			m41, m42, m43, m44
		), 4, 4)

	@Overload
	def __init__(self, matrix: Math.Tensor.Tensor):
		assert matrix.dimensions == (4, 4), 'Matrix must be 4x4'
		self.__matrix__: Math.Tensor.Tensor = matrix

	def __hash__(self) -> int:
		return hash(self.__matrix__)

	def __repr__(self) -> str:
		return f'<{TransformMatrix3D.__name__} 4x4 @ {hex(id(self))}>'

	def __str__(self) -> str:
		return str(self.__matrix__)

	def __abs__(self) -> TransformMatrix3D:
		return TransformMatrix3D(abs(self.__matrix__))

	def __round__(self, n: typing.Optional[int] = None) -> TransformMatrix3D:
		return TransformMatrix3D(round(self.__matrix__, n))

	def __add__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			return TransformMatrix3D(self.__matrix__ + other)
		elif isinstance(other, TransformMatrix3D):
			return TransformMatrix3D(self.__matrix__ + other.__matrix__)
		else:
			return NotImplemented

	def __sub__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			return TransformMatrix3D(self.__matrix__ - other)
		elif isinstance(other, TransformMatrix3D):
			return TransformMatrix3D(self.__matrix__ - other.__matrix__)
		else:
			return NotImplemented

	def __mul__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			return TransformMatrix3D(self.__matrix__ * other)
		elif isinstance(other, TransformMatrix3D):
			return TransformMatrix3D(self.__matrix__ * other.__matrix__)
		else:
			return NotImplemented

	def __matmul__(self, other: TransformMatrix3D) -> TransformMatrix3D:
		return TransformMatrix3D(self.__matrix__ @ other.__matrix__) if isinstance(other, TransformMatrix3D) else NotImplemented

	def __truediv__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			return TransformMatrix3D(self.__matrix__ / other)
		elif isinstance(other, TransformMatrix3D):
			return TransformMatrix3D(self.__matrix__ / other.__matrix__)
		else:
			return NotImplemented

	def __floordiv__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			return TransformMatrix3D(self.__matrix__ // other)
		elif isinstance(other, TransformMatrix3D):
			return TransformMatrix3D(self.__matrix__ // other.__matrix__)
		else:
			return NotImplemented

	def __mod__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			return TransformMatrix3D(self.__matrix__ % other)
		elif isinstance(other, TransformMatrix3D):
			return TransformMatrix3D(self.__matrix__ % other.__matrix__)
		else:
			return NotImplemented

	def __divmod__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			return TransformMatrix3D(divmod(self.__matrix__, other))
		elif isinstance(other, TransformMatrix3D):
			return TransformMatrix3D(divmod(self.__matrix__, other.__matrix__))
		else:
			return NotImplemented

	def __pow__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			return TransformMatrix3D(self.__matrix__ ** other)
		elif isinstance(other, TransformMatrix3D):
			return TransformMatrix3D(self.__matrix__ ** other.__matrix__)
		else:
			return NotImplemented

	def __radd__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			return TransformMatrix3D(other + self.__matrix__)
		elif isinstance(other, TransformMatrix3D):
			return TransformMatrix3D(other.__matrix__ + self.__matrix__)
		else:
			return NotImplemented

	def __rsub__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			return TransformMatrix3D(other - self.__matrix__)
		elif isinstance(other, TransformMatrix3D):
			return TransformMatrix3D(other.__matrix__ - self.__matrix__)
		else:
			return NotImplemented

	def __rmul__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			return TransformMatrix3D(other * self.__matrix__)
		elif isinstance(other, TransformMatrix3D):
			return TransformMatrix3D(other.__matrix__ * self.__matrix__)
		else:
			return NotImplemented

	def __rmatmul__(self, other: TransformMatrix3D) -> TransformMatrix3D:
		return TransformMatrix3D(other.__matrix__ @ self.__matrix__) if isinstance(other, TransformMatrix3D) else NotImplemented

	def __rtruediv__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			return TransformMatrix3D(other / self.__matrix__)
		elif isinstance(other, TransformMatrix3D):
			return TransformMatrix3D(other.__matrix__ / self.__matrix__)
		else:
			return NotImplemented

	def __rfloordiv__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			return TransformMatrix3D(other // self.__matrix__)
		elif isinstance(other, TransformMatrix3D):
			return TransformMatrix3D(other.__matrix__ // self.__matrix__)
		else:
			return NotImplemented

	def __rmod__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			return TransformMatrix3D(other % self.__matrix__)
		elif isinstance(other, TransformMatrix3D):
			return TransformMatrix3D(other.__matrix__ % self.__matrix__)
		else:
			return NotImplemented

	def __rdivmod__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			return TransformMatrix3D(divmod(other, self.__matrix__))
		elif isinstance(other, TransformMatrix3D):
			return TransformMatrix3D(divmod(other.__matrix__, self.__matrix__))
		else:
			return NotImplemented

	def __rpow__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			return TransformMatrix3D(other ** self.__matrix__)
		elif isinstance(other, TransformMatrix3D):
			return TransformMatrix3D(other.__matrix__ ** self.__matrix__)
		else:
			return NotImplemented

	def __iadd__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			self.__matrix__ += other
			return self
		elif isinstance(other, TransformMatrix3D):
			self.__matrix__ += other.__matrix__
			return self
		else:
			return NotImplemented

	def __isub__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			self.__matrix__ -= other
			return self
		elif isinstance(other, TransformMatrix3D):
			self.__matrix__ -= other.__matrix__
			return self
		else:
			return NotImplemented

	def __imul__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			self.__matrix__ *= other
			return self
		elif isinstance(other, TransformMatrix3D):
			self.__matrix__ *= other.__matrix__
			return self
		else:
			return NotImplemented

	def __imatmul__(self, other: TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, TransformMatrix3D):
			self.__matrix__ @= other.__matrix__
			return self
		else:
			return NotImplemented

	def __itruediv__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			self.__matrix__ /= other
			return self
		elif isinstance(other, TransformMatrix3D):
			self.__matrix__ /= other.__matrix__
			return self
		else:
			return NotImplemented

	def __ifloordiv__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			self.__matrix__ //= other
			return self
		elif isinstance(other, TransformMatrix3D):
			self.__matrix__ //= other.__matrix__
			return self
		else:
			return NotImplemented

	def __imod__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			self.__matrix__ %= other
			return self
		elif isinstance(other, TransformMatrix3D):
			self.__matrix__ %= other.__matrix__
			return self
		else:
			return NotImplemented

	def __ipow__(self, other: float | int | TransformMatrix3D) -> TransformMatrix3D:
		if isinstance(other, (float, int)):
			self.__matrix__ **= other
			return self
		elif isinstance(other, TransformMatrix3D):
			self.__matrix__ **= other.__matrix__
			return self
		else:
			return NotImplemented

	def __neg__(self) -> TransformMatrix3D:
		return TransformMatrix3D(-self.__matrix__)

	def __pos__(self) -> TransformMatrix3D:
		return TransformMatrix3D(+self.__matrix__)

	def transform_normal(self, vector: Vector3D) -> Vector3D:
		pass

	def inverse(self) -> TransformMatrix3D:
		pass

	@property
	def right(self) -> Vector3D:
		return Vector3D(self.__matrix__[0, :-1])

	@property
	def up(self) -> Vector3D:
		return Vector3D(self.__matrix__[1, :-1])

	@property
	def forward(self) -> Vector3D:
		return Vector3D(self.__matrix__[2, :-1])

	@property
	def translation(self) -> Vector3D:
		return Vector3D(self.__matrix__[3, :-1])

	@property
	def left(self) -> Vector3D:
		return -self.right

	@property
	def down(self) -> Vector3D:
		return -self.up

	@property
	def backward(self) -> Vector3D:
		return -self.forward

	@property
	def scale(self) -> Vector3D:
		return Vector3D(self.right.length(), self.up.length(), self.forward.length())

	@property
	def rotation(self) -> Math.Tensor.Tensor:
		return self.__matrix__.subtensor(3, 3)

	@right.setter
	def right(self, vector: Math.Vector.Vector) -> None:
		assert vector.dimension == 3, 'Vector must be 3D'
		matrix: list[float | None] = list(self.__matrix__.flattened())
		matrix[0], matrix[1], matrix[2] = vector
		self.__matrix__ = Math.Tensor.Tensor.shaped(matrix, 4, 4)

	@up.setter
	def up(self, vector: Math.Vector.Vector) -> None:
		assert vector.dimension == 3, 'Vector must be 3D'
		matrix: list[float | None] = list(self.__matrix__.flattened())
		matrix[4], matrix[5], matrix[6] = vector
		self.__matrix__ = Math.Tensor.Tensor.shaped(matrix, 4, 4)

	@forward.setter
	def forward(self, vector: Math.Vector.Vector) -> None:
		assert vector.dimension == 3, 'Vector must be 3D'
		matrix: list[float | None] = list(self.__matrix__.flattened())
		matrix[8], matrix[9], matrix[10] = vector
		self.__matrix__ = Math.Tensor.Tensor.shaped(matrix, 4, 4)

	@translation.setter
	def translation(self, vector: Math.Vector.Vector) -> None:
		assert vector.dimension == 3, 'Vector must be 3D'
		matrix: list[float | None] = list(self.__matrix__.flattened())
		matrix[12], matrix[13], matrix[14] = vector
		self.__matrix__ = Math.Tensor.Tensor.shaped(matrix, 4, 4)

	@left.setter
	def left(self, vector: Math.Vector.Vector) -> None:
		assert vector.dimension == 3, 'Vector must be 3D'
		matrix: list[float | None] = list(self.__matrix__.flattened())
		matrix[0], matrix[1], matrix[2] = -vector
		self.__matrix__ = Math.Tensor.Tensor.shaped(matrix, 4, 4)

	@down.setter
	def down(self, vector: Math.Vector.Vector) -> None:
		assert vector.dimension == 3, 'Vector must be 3D'
		matrix: list[float | None] = list(self.__matrix__.flattened())
		matrix[4], matrix[5], matrix[6] = -vector
		self.__matrix__ = Math.Tensor.Tensor.shaped(matrix, 4, 4)

	@backward.setter
	def backward(self, vector: Math.Vector.Vector) -> None:
		assert vector.dimension == 3, 'Vector must be 3D'
		matrix: list[float | None] = list(self.__matrix__.flattened())
		matrix[8], matrix[9], matrix[10] = -vector
		self.__matrix__ = Math.Tensor.Tensor.shaped(matrix, 4, 4)

	@rotation.setter
	def rotation(self, rotation: Math.Tensor.Tensor) -> None:
		assert rotation.dimension == 2 and rotation.dimensions == (3, 3), 'Matrix must be a 3x3 rotation matrix'
		m11, m12, m13, m21, m22, m23, m31, m32, m33 = rotation
		m41, m42, m43 = self.translation
		self.__matrix__ = Math.Tensor.Tensor.shaped((
			m11, m12, m13, 0,
			m21, m22, m23, 0,
			m31, m32, m33, 0,
			m41, m42, m43, 1,
		), 4, 4)

	@scale.setter
	def scale(self, scale: Math.Vector.Vector) -> None:
		x, y, z = scale.components()
		self.right = self.right.normalized() * x
		self.up = self.up.normalized() * y
		self.forward = self.forward.normalized() * z


class Vector3D(Math.Vector.Vector):
	@classmethod
	def zero(cls) -> Vector3D:
		return cls(0)

	@classmethod
	def one(cls) -> Vector3D:
		return cls(1)

	@DefaultOverload
	def __init__(self):
		super().__init__(0, 0, 0)

	@Overload
	def __init__(self, xyz: float):
		Misc.raise_ifn(isinstance(xyz, (float, int)), Exceptions.InvalidArgumentException(Vector3D.__init__, 'xyz', type(xyz), (float, int)))
		super().__init__(xyz, xyz, xyz)

	@Overload
	def __init__(self, vector: Math.Vector.Vector | Vector3D):
		Misc.raise_ifn(isinstance(vector, Math.Vector.Vector), Exceptions.InvalidArgumentException(Vector3D.__init__, 'vector', type(vector), (Math.Vector.Vector, Vector3D)))
		super().__init__(*vector)

	@Overload
	def __init__(self, x: float, y: float, z: float):
		Misc.raise_ifn(isinstance(x, (float, int)), Exceptions.InvalidArgumentException(Vector3D.__init__, 'x', type(x), (float, int)))
		Misc.raise_ifn(isinstance(y, (float, int)), Exceptions.InvalidArgumentException(Vector3D.__init__, 'y', type(y), (float, int)))
		Misc.raise_ifn(isinstance(z, (float, int)), Exceptions.InvalidArgumentException(Vector3D.__init__, 'z', type(z), (float, int)))
		super().__init__(x, y, z)

