

def mass_to_mol():
	pass
