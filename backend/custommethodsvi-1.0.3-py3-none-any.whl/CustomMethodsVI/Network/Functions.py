import math


def baudrate(bps: float, states: int) -> float:
	return 2 * bps * math.log2(states)


def baudrate_noise(bps: float, signal_strength: float, noise_strength: float) -> float:
	"""
	Shannon formula for thermal noise
	:param bps: The bits per second
	:param signal_strength: The true signal strength
	:param noise_strength: The noise signal strength
	:return: The maximum baud-rate
	"""

	return bps * math.log2(signal_strength / noise_strength + 1)


def baudrate_noise_db(bps: float, decibel_ratio: float) -> float:
	"""
	Shannon formula derived for decibels
	:param bps:
	:param decibel_ratio:
	:return:
	"""

	return bps * decibel_ratio / 3.01
