from .. import Exceptions
from .. import Math
from .. import Misc
from .. import Stream


class CodeDivisionMultiplexer:
	"""
	Class representing encoder/decoder for code division multiplexing
	"""

	def __init__(self, chips_per_bit: int):
		"""
		Class representing encoder/decoder for code division multiplexing
		- Constructor -
		:param chips_per_bit: The chips per bit for encoding. Higher values allow more users but is slower
		:raises InvalidArgumentException: If 'chips_per_bit' is not an integer
		:raises ValueError: If 'chips_per_bit' is <= 0
		"""

		Misc.raise_ifn(isinstance(chips_per_bit, int), Exceptions.InvalidArgumentException(CodeDivisionMultiplexer.__init__, 'chips_per_bit', type(chips_per_bit), (int,)))
		Misc.raise_ifn((chips_per_bit := int(chips_per_bit)) > 0, ValueError('Chips per bit must be greater than 0'))
		self.__chips_per_bit__: int = int(chips_per_bit)
		self.__user_data__: dict[Math.Vector.Vector, Stream.ByteStream] = {}
		self.__next_user_index__: int = 0

	def tick(self) -> None:
		pass

	def add_user(self) -> Math.Vector.Vector:
		pass

